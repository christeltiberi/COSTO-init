var searchData=
[
  ['file_0',['file',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#sz',1,'Delay times data file'],['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#st',1,'Gravity gradient data file'],['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#sq',1,'Regular gravity data file']]],
  ['file_20parameter_20inp_1',['2.1 File parameter.inp',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#bb',1,'']]],
  ['files_2',['files',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#cc',1,'2.2 Input files'],['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#ca',1,'2.3 Data files']]],
  ['findnod_3',['findnod',['../findnod_8f90.html#a93c5a24a00944379960ab8d86230234d',1,'findnod.f90']]],
  ['findnod_2ef90_4',['findnod.f90',['../findnod_8f90.html',1,'']]],
  ['for_20gravity_5',['3.2 For gravity',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#oi',1,'']]],
  ['for_20gravity_20gradient_6',['3.3 For gravity gradient',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#op',1,'']]],
  ['for_20joint_20inversion_7',['3.4 For joint inversion',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#ol',1,'']]],
  ['for_20tomography_8',['3.1 For tomography',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#oo',1,'']]],
  ['forw_9',['forw',['../forw_8f90.html#afea4d47db3797fc505105ce437ef033c',1,'forw.f90']]],
  ['forw_2ef90_10',['forw.f90',['../forw_8f90.html',1,'']]],
  ['frechet_11',['frechet',['../frechet_8f90.html#af42c587b537cdc353073ba2ff9c653f5',1,'frechet.f90']]],
  ['frechet_2ef90_12',['frechet.f90',['../frechet_8f90.html',1,'']]]
];
