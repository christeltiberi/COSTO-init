var searchData=
[
  ['gbox_0',['gbox',['../calgra_8f90.html#aa9508086ec6f203a8304fd9bee344d4c',1,'calgra.f90']]],
  ['general_20descriptions_1',['1. General descriptions',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#aa',1,'']]],
  ['gmatrix_2',['gmatrix',['../ttmder_8f90.html#a89954894e0570b1612d11e73c36d1572',1,'ttmder.f90']]],
  ['gradient_3',['3.3 For gravity gradient',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#op',1,'']]],
  ['gradient_20data_20file_4',['Gravity gradient data file',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#st',1,'']]],
  ['gravity_5',['3.2 For gravity',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#oi',1,'']]],
  ['gravity_20data_20file_6',['Regular gravity data file',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#sq',1,'']]],
  ['gravity_20gradient_7',['3.3 For gravity gradient',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#op',1,'']]],
  ['gravity_20gradient_20data_20file_8',['Gravity gradient data file',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#st',1,'']]],
  ['grread_9',['grread',['../grread_8f90.html#a82b5478be2fe07f2fbd738b00255b5ad',1,'grread.f90']]],
  ['grread_2ef90_10',['grread.f90',['../grread_8f90.html',1,'']]]
];
