var searchData=
[
  ['1_20file_20parameter_20inp_0',['2.1 File parameter.inp',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#bb',1,'']]],
  ['1_20for_20tomography_1',['3.1 For tomography',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#oo',1,'']]],
  ['1_20general_20descriptions_2',['1. General descriptions',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#aa',1,'']]]
];
