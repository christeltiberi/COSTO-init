var searchData=
[
  ['2_201_20file_20parameter_20inp_0',['2.1 File parameter.inp',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#bb',1,'']]],
  ['2_202_20input_20files_1',['2.2 Input files',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#cc',1,'']]],
  ['2_203_20data_20files_2',['2.3 Data files',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#ca',1,'']]],
  ['2_20for_20gravity_3',['3.2 For gravity',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#oi',1,'']]],
  ['2_20input_20files_4',['2.2 Input files',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#cc',1,'']]]
];
