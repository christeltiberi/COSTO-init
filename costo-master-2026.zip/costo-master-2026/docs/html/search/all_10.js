var searchData=
[
  ['parameter_20inp_0',['2.1 File parameter.inp',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#bb',1,'']]],
  ['pause_1',['pause',['../tesseroid_8c.html#ad74637df8ab081f644cb8f2175df273f',1,'pause():&#160;tesseroid.c'],['../tesseroid__gz_8c.html#ad74637df8ab081f644cb8f2175df273f',1,'pause():&#160;tesseroid_gz.c']]],
  ['perturb_2',['perturb',['../perturb_8f90.html#aa35e79c01d0b45c495bb5113f1253a72',1,'perturb.f90']]],
  ['perturb_2ef90_3',['perturb.f90',['../perturb_8f90.html',1,'']]],
  ['programs_4',['3. Sorting programs',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#XX',1,'']]]
];
