var searchData=
[
  ['model_0',['model',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#ss',1,'Density model'],['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#sss',1,'Velocity model']]]
];
