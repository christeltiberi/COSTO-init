var searchData=
[
  ['simplex_0',['simplex',['../simplex_8f90.html#a74599e64ca687eec313079e0663288e5',1,'simplex.f90']]],
  ['simplex_2ef90_1',['simplex.f90',['../simplex_8f90.html',1,'']]],
  ['sort_2',['sort',['../simplex_8f90.html#a5fbcc9c5f3a54e61145d3f63d582d586',1,'simplex.f90']]],
  ['sorting_20programs_3',['3. Sorting programs',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#XX',1,'']]],
  ['statcoord_4',['statcoord',['../statcoord_8f90.html#a9bce0643fb641e99a38165552da2763c',1,'statcoord.f90']]],
  ['statcoord_2ef90_5',['statcoord.f90',['../statcoord_8f90.html',1,'']]],
  ['switch_6',['switch',['../simplex_8f90.html#a3ac599a56c4a1aca9898ad12dd9e0332',1,'simplex.f90']]]
];
