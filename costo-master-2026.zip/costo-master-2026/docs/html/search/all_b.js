var searchData=
[
  ['info3d_0',['info3d',['../info3d_8f90.html#a335b506da1f96600e0d8ac2bf1c7fb57',1,'info3d.f90']]],
  ['info3d_2ef90_1',['info3d.f90',['../info3d_8f90.html',1,'']]],
  ['inp_2',['2.1 File parameter.inp',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#bb',1,'']]],
  ['input_20files_3',['2.2 Input files',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#cc',1,'']]],
  ['intmap_4',['intmap',['../vel3_8f90.html#a62c1d16ba9b98e34ff6c497e2fa5245f',1,'vel3.f90']]],
  ['invermat_5',['invermat',['../invermat_8f90.html#a31bcd8f59036b66132f0fac40ba47949',1,'invermat.f90']]],
  ['invermat_2ef90_6',['invermat.f90',['../invermat_8f90.html',1,'']]],
  ['inversion_7',['3.4 For joint inversion',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#ol',1,'']]]
];
