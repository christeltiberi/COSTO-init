var searchData=
[
  ['ddiffer_2ef90_0',['ddiffer.f90',['../ddiffer_8f90.html',1,'']]],
  ['ddiffergr_2ef90_1',['ddiffergr.f90',['../ddiffergr_8f90.html',1,'']]],
  ['denvel_2ef90_2',['denvel.f90',['../denvel_8f90.html',1,'']]],
  ['dgemm_2ef90_3',['dgemm.f90',['../dgemm_8f90.html',1,'']]],
  ['dgemv_2ef90_4',['dgemv.f90',['../dgemv_8f90.html',1,'']]],
  ['dsmooth_2ef90_5',['dsmooth.f90',['../dsmooth_8f90.html',1,'']]]
];
