var searchData=
[
  ['data_5firr_0',['data_irr',['../rdata_8f90.html#a060e10cfb439e75aa4b7328e7db5e1e6',1,'rdata.f90']]],
  ['data_5freg_1',['data_reg',['../rdata_8f90.html#ac2f563ea02c9b4e1382d41ee11ecbc40',1,'rdata.f90']]],
  ['ddiffer_2',['ddiffer',['../ddiffer_8f90.html#a9fc0804142f82870f4404168c9ea9cfb',1,'ddiffer.f90']]],
  ['ddiffergr_3',['ddiffergr',['../ddiffergr_8f90.html#a0c0d396e0214364826c42be9991dcb58',1,'ddiffergr.f90']]],
  ['delaz_4',['delaz',['../statcoord_8f90.html#a62377af4ff79015ff9e9e60d9a6be1f9',1,'statcoord.f90']]],
  ['denvel_5',['denvel',['../denvel_8f90.html#a6331f7edeebf7112a778cca1c6971773',1,'denvel.f90']]],
  ['dgemm_6',['dgemm',['../dgemm_8f90.html#a1e899f8453bcbfde78e91a86a2dab984',1,'dgemm.f90']]],
  ['dgemv_7',['dgemv',['../dgemv_8f90.html#a4ac1b675072d18f902db8a310784d802',1,'dgemv.f90']]],
  ['dmfsd_8',['dmfsd',['../invermat_8f90.html#ab7eed0dcfb3ad3ddf7cd35ebbecba2bc',1,'invermat.f90']]],
  ['dsinv_9',['dsinv',['../invermat_8f90.html#a759ad135721222902e554f7f44e578e0',1,'invermat.f90']]],
  ['dsmooth_10',['dsmooth',['../dsmooth_8f90.html#ab4543a90fc849957ac13f00fd1a8bb83',1,'dsmooth.f90']]]
];
