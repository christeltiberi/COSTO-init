var searchData=
[
  ['bcalc_0',['bcalc',['../bcalc_8f90.html#a2deb1e3ffa85351cd8b606d1a9a81ce2',1,'bcalc(nbod, ilay, par, ibove, iiter, thrhold):&#160;bcalc.f90'],['../bcalc_8ori_8f90.html#ad6f7968d5d90937fde490bf74af85ba9',1,'bcalc(nbod, nnod, ilay, par, dvrho, ibove):&#160;bcalc.ori.f90']]],
  ['bdiffer_1',['bdiffer',['../bdiffer_8f90.html#aebff3c2d3320e872858a79136670c482',1,'bdiffer.f90']]],
  ['bldmap_2',['bldmap',['../bldmap_8f90.html#af2d16b5534baf1c51fb0e06c19edb10d',1,'bldmap.f90']]],
  ['bldmat_3',['bldmat',['../bldmat_8f90.html#ab376c4fab62eb6a3cb943eb16255bd0c',1,'bldmat(iiter, aderi, bderi, punvar, varpar, h1, diff, npar, npar1, ndat, smooth, iside, jside, ivside, jvside, xb, yb, vxnodes, vynodes, par, ibove, ismooth, ilay, ddvr, nbod):&#160;bldmat.f90'],['../bldmat__old_8f90.html#a0bb530402648ffb40b37006071245973',1,'bldmat(iiter, aderi, bderi, cderi, punvar, varpar, h1, diff, np:&#160;bldmat_old.f90']]],
  ['blockmean_4',['blockmean',['../bdiffer_8f90.html#a778b54c9c5978b1e933d8698e8f68003',1,'bdiffer.f90']]]
];
