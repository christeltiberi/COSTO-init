var searchData=
[
  ['simplex_0',['simplex',['../simplex_8f90.html#a74599e64ca687eec313079e0663288e5',1,'simplex.f90']]],
  ['sort_1',['sort',['../simplex_8f90.html#a5fbcc9c5f3a54e61145d3f63d582d586',1,'simplex.f90']]],
  ['statcoord_2',['statcoord',['../statcoord_8f90.html#a9bce0643fb641e99a38165552da2763c',1,'statcoord.f90']]],
  ['switch_3',['switch',['../simplex_8f90.html#a3ac599a56c4a1aca9898ad12dd9e0332',1,'simplex.f90']]]
];
