var searchData=
[
  ['pause_0',['pause',['../tesseroid_8c.html#ad74637df8ab081f644cb8f2175df273f',1,'pause():&#160;tesseroid.c'],['../tesseroid__gz_8c.html#ad74637df8ab081f644cb8f2175df273f',1,'pause():&#160;tesseroid_gz.c']]],
  ['perturb_1',['perturb',['../perturb_8f90.html#aa35e79c01d0b45c495bb5113f1253a72',1,'perturb.f90']]]
];
