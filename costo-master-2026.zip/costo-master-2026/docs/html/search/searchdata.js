var indexSectionsWithContent =
{
  0: "12345abcdfgijlmoprstvz",
  1: "abcdfgijloprstvz",
  2: "abcdfgilmoprstvz",
  3: "12345dfgijmoprstv"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Pages"
};

