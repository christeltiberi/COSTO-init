var searchData=
[
  ['file_0',['file',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#sz',1,'Delay times data file'],['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#st',1,'Gravity gradient data file'],['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#sq',1,'Regular gravity data file']]],
  ['file_20parameter_20inp_1',['2.1 File parameter.inp',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#bb',1,'']]],
  ['files_2',['files',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#cc',1,'2.2 Input files'],['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#ca',1,'2.3 Data files']]],
  ['for_20gravity_3',['3.2 For gravity',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#oi',1,'']]],
  ['for_20gravity_20gradient_4',['3.3 For gravity gradient',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#op',1,'']]],
  ['for_20joint_20inversion_5',['3.4 For joint inversion',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#ol',1,'']]],
  ['for_20tomography_6',['3.1 For tomography',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#oo',1,'']]]
];
