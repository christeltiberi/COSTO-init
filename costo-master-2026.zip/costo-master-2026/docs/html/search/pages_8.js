var searchData=
[
  ['inp_0',['2.1 File parameter.inp',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#bb',1,'']]],
  ['input_20files_1',['2.2 Input files',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#cc',1,'']]],
  ['inversion_2',['3.4 For joint inversion',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#ol',1,'']]]
];
