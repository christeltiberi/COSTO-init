var searchData=
[
  ['gbox_0',['gbox',['../calgra_8f90.html#aa9508086ec6f203a8304fd9bee344d4c',1,'calgra.f90']]],
  ['gmatrix_1',['gmatrix',['../ttmder_8f90.html#a89954894e0570b1612d11e73c36d1572',1,'ttmder.f90']]],
  ['grread_2',['grread',['../grread_8f90.html#a82b5478be2fe07f2fbd738b00255b5ad',1,'grread.f90']]]
];
