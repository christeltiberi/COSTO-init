var searchData=
[
  ['3_201_20for_20tomography_0',['3.1 For tomography',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#oo',1,'']]],
  ['3_202_20for_20gravity_1',['3.2 For gravity',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#oi',1,'']]],
  ['3_203_20for_20gravity_20gradient_2',['3.3 For gravity gradient',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#op',1,'']]],
  ['3_204_20for_20joint_20inversion_3',['3.4 For joint inversion',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#ol',1,'']]],
  ['3_205_20others_4',['3.5 Others',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#om',1,'']]],
  ['3_20data_20files_5',['2.3 Data files',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#ca',1,'']]],
  ['3_20for_20gravity_20gradient_6',['3.3 For gravity gradient',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#op',1,'']]],
  ['3_20sorting_20programs_7',['3. Sorting programs',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#XX',1,'']]]
];
