var searchData=
[
  ['general_20descriptions_0',['1. General descriptions',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#aa',1,'']]],
  ['gradient_1',['3.3 For gravity gradient',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#op',1,'']]],
  ['gradient_20data_20file_2',['Gravity gradient data file',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#st',1,'']]],
  ['gravity_3',['3.2 For gravity',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#oi',1,'']]],
  ['gravity_20data_20file_4',['Regular gravity data file',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#sq',1,'']]],
  ['gravity_20gradient_5',['3.3 For gravity gradient',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#op',1,'']]],
  ['gravity_20gradient_20data_20file_6',['Gravity gradient data file',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#st',1,'']]]
];
