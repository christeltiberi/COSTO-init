var searchData=
[
  ['data_20file_0',['data file',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#sz',1,'Delay times data file'],['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#st',1,'Gravity gradient data file'],['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#sq',1,'Regular gravity data file']]],
  ['data_20files_1',['2.3 Data files',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#ca',1,'']]],
  ['delay_20times_20data_20file_2',['Delay times data file',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#sz',1,'']]],
  ['density_20model_3',['Density model',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#ss',1,'']]],
  ['descriptions_4',['1. General descriptions',['..//Users/christel/Sync/MATTHIEU/COSTO/SRC/costo-master-2026/joint_inv.f90#aa',1,'']]]
];
