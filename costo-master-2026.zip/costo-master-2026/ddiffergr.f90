!=====================================================================
!=====================================================================
!
!			SUBROUTINE DDIFFERGR
!
!> subroutine calculates the difference between observed and calculated
!! gradiometry data (USEDATA, CALDATA) and uses it to compute the Root Mean
!! Square (RMSGR)
!!
!! Also calculates the difference between previous (PAR0) and actual (PAR)
!! parameters if there is not gravity inversion
!
! This is useful for testing the threshold to stop the iteration. If the
! sum of differences is small enough, we stop.

!=====================================================================
!=====================================================================

SUBROUTINE DDIFFERGR(usedata,caldata,rmsgr,iiter,par,par0,punvar,rovar,&
                     varpar,xb,yb,zb,ismooth,smooth,iside,jside,&
                     diff,dtot,grdtot,h1,bderi,npts,errclgr,rtvar,ncomp)

USE MOD_delim
USE MOD_unit
USE MOD_inv

USE MOD_dsmooth

USE MOD_ddiffer
USE MOD_grread

IMPLICIT NONE

!=====================================================================
! Declaration of the in/out arguments of DIFFER
!=====================================================================
integer,intent(in)                               :: iiter
real(kind=8),DIMENSION(:),pointer                :: usedata,caldata
real(kind=8),DIMENSION(:,:),intent(inout)        :: rmsgr,errclgr
real(kind=8),DIMENSION(:),intent(in)             :: par,par0
real(kind=8),DIMENSION(:,:),intent(inout)        :: rovar
real(kind=8),DIMENSION(:),intent(inout)          :: diff,grdtot
real(kind=8),DIMENSION(:),pointer                :: punvar

! pour la partie modèle de densité
integer :: dcont
integer,intent(in)                               :: ismooth
integer,DIMENSION(:),intent(in)                  :: iside
integer,DIMENSION(:,:),intent(in)                :: jside
real(kind=8)                                     :: difs,dsum
real(kind=8),DIMENSION(:),intent(in)             :: smooth
real(kind=8),DIMENSION(:,:),intent(in)           :: xb,yb,zb
real(kind=8),DIMENSION(:),intent(inout)          :: h1
real(kind=8),DIMENSION(:,:),intent(inout)        :: bderi,dtot
real(kind=8),DIMENSION(:),intent(in)             :: varpar

integer,DIMENSION(:),intent(in)      :: npts

real(kind=8),DIMENSION(:),intent(in)    :: rtvar         ! MP36
integer,intent(inout)                   :: ncomp         ! MP36


!=====================================================================
! Declaration of the dummy arguments of DIFFER
!=====================================================================
integer                                :: i,id,j,ig,nbn
real(kind=8)                           :: maxdif,absdif
real(kind=8)                           :: dev,difgr,difd
real(kind=8)                           :: mean,s

real(kind=8),DIMENSION(:),allocatable :: rmsgr2
integer :: iter

real(kind=8),DIMENSION(6)              :: test          ! MP36 


!=====================================================================
! Writting some outputs
!=====================================================================
   write(*,*)''
   write(*,*)'COMPUTING THE DIFFERENCES BETWEEN OBS. AND CALC FTG DATA'
   if(iiter.eq.1) then
      write(inout,*)''
      write(inout,*)'DDIFFERGR CALLED FOR COMPUTING INITIAL SDT DEVIATION'
      write(inout,*)'ITERATION = 0'
   else
      write(inout,*)''
      write(inout,*)'DDIFFERGR CALLED FOR DIFFERENCE BETWEEN OBS. and CALC'
      write(inout,*)'ITERATION = ',iiter
   end if
   
   if(jbegin(3).eq.0) then
      write(*,*)''
      write(*,*)'Inconsistency in DDIFFERGR: data file is &
                 &read, but no data are stored.'
      STOP 'in DDIFFERGR.'
   end if

!=====================================================================
! Differences between observed and calculated FTG DATA
!
! Unlike GRAVI, there are 6 components.
! Given that the RMS is only used as information, and not in a calculation:
! we calculate an average rms and an rms per component.
! This help to see if a particular component is better fitted
! 
!          _________________________________
! RMSGR(2:7) = V ( Sum[(obs(2:7)-calc(2:7))**2] / (Ndata-1) 
! RMSGR(1)= sum RMSGR(2:7) / 6
! Organized in the following order: average / XX / XY / XZ / YY / YZ / ZZ
! VARIANCE = ROVAR = Sum[x - moy]**2/(Ndata - 1)
!=====================================================================
   maxdif = 0.d0
   mean = 0.d0
   s = 0.d0

   if(.not.INVD) then
      rovar(iiter,:) = 0.0d0
   endif

! ROVAR dimension? initially with ALLOCATE (rovar(iter+1,2)) 
! column 1 : GRAVI data
! column 2 : parameter
! ADD column 3 for gradio data so there's no need to change the other codes
! which are already set with columns 1 and 2 
! Calculation of RMS for all components

   do i=jbegin(3),jend(3)
      mean = mean + caldata(i)
      diff(i) = usedata(i) - caldata(i)
      absdif = dabs(diff(i))
      if(absdif.gt.maxdif) maxdif = absdif
      rmsgr(iiter,1) = rmsgr(iiter,1) + diff(i)*diff(i)
   end do

   if(jend(3).gt.jbegin(3)) then
      mean = mean/(jend(3)-jbegin(3)+1)
      rmsgr(iiter,1) = dsqrt(rmsgr(iiter,1)/(jend(3)-jbegin(3)))
   else
      write(*,*)'    Can''t calculate the standard deviation'
      STOP ' in DDIFFERGR: jend(3)-jbegin(3)=0 !'
   end if

! RMS calculation for each component'
allocate(rmsgr2(ncomp))
rmsgr2(:)=0

      nbn=0     ! To take into account the nb of methods we invert in addition to gradio
      if (INVD) then
        nbn=nbn+1
      endif
      if (INVV) then
        nbn=nbn+1
      endif

    do j=1,ncomp
       do i=jbegin(3)+(j-1)*((jend(3)-jbegin(3)+1)/ncomp),jbegin(3)+(j)*((jend(3)-jbegin(3)+1)/ncomp)-1 
          rmsgr(iiter,j+1) = rmsgr(iiter,j+1) + diff(i)*diff(i)
       end do
          rmsgr(iiter,j+1) = dsqrt(rmsgr(iiter,j+1)/(((jend(3)-jbegin(3)+1)/ncomp)-1)) 

    end do

    do j=1,ncomp
      rmsgr2(j)=rmsgr(iiter,j+1)
    enddo
    
    iter=0
    do j=1,6
      if (rtvar(nbn+j) .ne. 0) then
 !       rmsgr(iiter,j+1)=rmsgr2(j-iter)
 !     else
 !       iter=iter+1
 !       rmsgr(iiter,j+1)=0
        iter=iter+1
        rmsgr(iiter,j+1)=rmsgr2(iter)   ! iter counts active components
      else
        rmsgr(iiter,j+1)=0
      endif
    enddo

   do i=jbegin(3),jend(3)
      s = caldata(i) - mean
      rovar(iiter,3) = rovar(iiter,3) + s*s
   end do

   if(jend(3).gt.jbegin(3)) then
      rovar(iiter,3) = rovar(iiter,3)/(jend(3)-jbegin(3))
      write(inout,'(5x,''Variance of the calculated FTG:'',22(''.''),&
           &f12.3)') rovar(iiter,3)
      write(inout,'(5x,''Mean of the calculated FTG:'',26(''.''),&
           &f12.3)') mean
   else
      write(*,*)'    Can''t calculate the variance'
      STOP ' in DDIFFERGR : jend(3)-jbegin(3)=0 !'
   end if

   write(inout,'(5x,''Max. difference between obs. and calc. FTG &
        &data:'',5(''.''),f12.3,'' E'')') maxdif

   write(*,'(5x,''Max. difference between obs. and calc. FTG &
        &data:'',5(''.''),f12.3,'' E'')') maxdif

!=====================================================================
! Differences between observed and calculated data points
!=====================================================================
   difgr = 0.d0
   ig = 0
   do i=jbegin(3),jend(3)
      ig=ig+1
      difgr = difgr + diff(i)*diff(i)*punvar(i)
! test CT 26-03-2026
!      write(*,*) "ig= ,", ig ,"difgr= ,", difgr ,"diff= ,",diff(i)," pun(i)= ", punvar(i)
   end do
   difgr = difgr/ig

! the next 3 parts are only calculated if there is no gravity inversion 
! otherwise no need till it's already done in the gravi part (DDIFFER)
!=====================================================================
! Differences between previous and actual parameters
!=====================================================================
   if(.not.INVD) then
      id = 0
      dev = 0.d0
      difd = 0.d0
      mean=0.d0
      s=0.d0
      do i=ibegin(1),iend(1)
         mean=mean+par(i)
         dev = par(i) - par0(i)
         id = id+1
         difd = difd + dev*dev*varpar(i)
      end do
      difd = difd/id
      mean = mean/id
   
!=====================================================================
! Variances of the actual parameters
!=====================================================================
      do i=ibegin(1),iend(1)
         s=par(i)-mean
         rovar(iiter,2)=rovar(iiter,2) + s*s
      end do

      rovar(iiter,2)=rovar(iiter,2)/(iend(1)-ibegin(1))

!=====================================================================
! If Smoothing constraint is present and iteration .gt. 1,
! it returns the difference between parameters of contiguous blocks
! weighted by their distance and smoothing factor.
!=====================================================================
      if(ismooth.ne.0 .and. iiter.gt.1) then
         CALL DSMOOTH(smooth,iside,jside,xb,yb,par,dsum,dcont,&
                      bderi,h1)
         if(dcont.ne.0) difs=dsum/dcont
      else
         difs = 0.d0
      end if

      dtot(iiter,1) = 0
      dtot(iiter,2) = difd
      dtot(iiter,3) = difs
      dtot(iiter,4) = difd+difs
   endif

      grdtot(iiter)=difgr

      write(*,'(5x,''RMS of obs-calc FTG data (mean of all components):'',28(''.''),&
           &f12.3,'' E'')') rmsgr(iiter,1)
      write(*,'(5x,''    - for XX components:'',28(''.''),f12.3,'' E'')') rmsgr(iiter,2)
      write(*,'(5x,''    - for XY components:'',28(''.''),f12.3,'' E'')') rmsgr(iiter,3)
      write(*,'(5x,''    - for XZ components:'',28(''.''),f12.3,'' E'')') rmsgr(iiter,4)
      write(*,'(5x,''    - for YY components:'',28(''.''),f12.3,'' E'')') rmsgr(iiter,5)
      write(*,'(5x,''    - for YZ components:'',28(''.''),f12.3,'' E'')') rmsgr(iiter,6)
      write(*,'(5x,''    - for ZZ components:'',28(''.''),f12.3,'' E'')') rmsgr(iiter,7)

      write(inout,'(5x,''RMS of obs-calc FTG data (mean of all components) :'',28(''.''),&
           &f12.3,'' E'')') rmsgr(iiter,1)
      write(inout,'(5x,''    - for XX components:'',28(''.''),f12.3,'' E'')') rmsgr(iiter,2)
      write(inout,'(5x,''    - for XY components:'',28(''.''),f12.3,'' E'')') rmsgr(iiter,3)
      write(inout,'(5x,''    - for XZ components:'',28(''.''),f12.3,'' E'')') rmsgr(iiter,4)
      write(inout,'(5x,''    - for YY components:'',28(''.''),f12.3,'' E'')') rmsgr(iiter,5)
      write(inout,'(5x,''    - for YZ components:'',28(''.''),f12.3,'' E'')') rmsgr(iiter,6)
      write(inout,'(5x,''    - for ZZ components:'',28(''.''),f12.3,'' E'')') rmsgr(iiter,7)

      write(inout,'(5x,''Sum of mean diff. for gravity/density:'',19(''.''),&
           &f12.3)') dtot(iiter,4)

      write(inout,*)'    whereof:'

      write(inout,'(13x,''Mean diff. between obs. and calc. FTG data:..&
           &'',f12.3,'' E'')') difgr

!      write(inout,'(13x,''toto'',f12.3)') dtot(iiter,4)      

      write(inout,'(13x,''Mean diff. between act. and prev. &
           &parameters:'',4(''.''),f12.3)') difd

      write(inout,'(5x,''Roughness from smoothing constraint:'',21(''.''),&
           &f12.3)') difs

!calculation of the error like Clémence without the weighting part of each method (alpha)
! One error for all the data
do i=jbegin(3),jend(3)
  diff(i)=usedata(i)-caldata(i)
  errclgr(iiter,1) = errclgr(iiter,1) + ((diff(i)*diff(i))/((1/punvar(i))*((jend(3)-jbegin(3)+1))))

enddo

END SUBROUTINE
