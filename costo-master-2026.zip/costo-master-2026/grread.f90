!=====================================================================
!=====================================================================
! SUBROUTINE GRREAD
!
! Read the gradient data file and store the fieldpoints and data
! in an array storage
!
! 2026-03-26 FIXED for NaN and segmentation fault. Bad loops dimension
!            FIXED the min-max amplitude to remain in the selected area
! 2026-04-02 FIXED segmentation fault due to ptvar3 not returned if not INV
!
! Called from RDATA subroutine
! Calls none
!
! Don't forget to change MOD_grread if you change the subroutine
!=====================================================================
    SUBROUTINE GRREAD(fdata,ifil,modvar,rtvar,npts,grFX,grFY,grFZ,&
                        XX,XY,XZ,YY,YZ,ZZ,ptvar3,ncomp)

        USE MOD_unit
        USE MOD_layer
        USE MOD_size
        USE MOD_inv

      IMPLICIT NONE

      character(len=80),intent(in)          :: fdata

      integer,intent(in)                      :: ifil
      integer,DIMENSION(:),intent(inout)      :: npts
      integer,intent(inout)                   :: ncomp
      integer,DIMENSION(:),intent(in)         :: modvar
      real(kind=8),DIMENSION(:),intent(in)    :: rtvar
      real(kind=8),DIMENSION(:),pointer       :: ptvar3

      real(kind=8),DIMENSION(:),pointer       :: grFX,grFY,grFZ
      real(kind=8),DIMENSION(:),pointer       :: XX,XY,XZ,YY,YZ,ZZ


!=====================================================================
! Declaration of dummy arguments for GRREAD
!=====================================================================
      character(len=80)                        :: dummy

      integer                                  :: num,nptot,i,j,itake,iter,nbn
      real(kind=8),DIMENSION(:,:),ALLOCATABLE  :: datatot
      real(kind=8)                             :: xmin,xmax,ymin,ymax
      real(kind=8)                             :: perc
      real(kind=8),DIMENSION(:),ALLOCATABLE    :: ptvar,perc2

!      print*,"on est dans la subroutine GRREAD"   

!=====================================================================
! Read the general boundaries and the used ones in data file
!=====================================================================
      inquire(file=fdata,number=num)
      write(*,*)'    logical unit currently read:',num,',',fdata
      read(num,*) dummy
      read(num,*) nptot

!=====================================================================
! Allocation of the data and position array
!=====================================================================
      ALLOCATE (datatot(nptot,9))

!=====================================================================
! Read coordinates of the inversion area 
!=====================================================================   
      read(num,*) dummy
      read(num,*) xmin,xmax,ymin,ymax
      read(num,*) dummy

! calculation of the number of components to be inverted (or modelled)

      ncomp=0
! to take into account the number of methods that are inversed in addition to the gradio:
      nbn=0   

      if (INVD) then
        nbn=nbn+1
      endif

      if (INVV) then
        nbn=nbn+1
      endif

      do i=1,6
        if (rtvar(nbn+i) .ne. 0) then
          ncomp=ncomp+1
        endif
      enddo

!=====================================================================
! Read position of all x,y,z and FTG data
!=====================================================================   
      do i=1,nptot
         read(num,*) datatot(i,1),datatot(i,2),datatot(i,3),datatot(i,4),datatot(i,5),&
            datatot(i,6),datatot(i,7),datatot(i,8),datatot(i,9)

         if(datatot(i,1).ge.xmin.and.datatot(i,1).le.xmax) then
            if(datatot(i,2).ge.ymin.and.datatot(i,2).le.ymax) then
                  npts(ifil)=npts(ifil)+1
            end if
         end if
      end do

!=====================================================================
! Allocation of the data and position array for used data
!=====================================================================
      write(*,*)'    Number of used data for FTG file: ',npts(ifil)
      write(inout,*)''
      write(inout,*)'    Number of used data for FTG file: ',&
           npts(ifil)
      ALLOCATE (grFX(npts(ifil)))
      ALLOCATE (grFY(npts(ifil)))
      ALLOCATE (grFZ(npts(ifil)))
      ALLOCATE (XX(npts(ifil)),XY(npts(ifil)),XZ(npts(ifil)))
      ALLOCATE (YY(npts(ifil)),YZ(npts(ifil)),ZZ(npts(ifil)))
      ALLOCATE (ptvar(nptot*6))
! CT 2026-03-26 
! must be nptot: fill loop indexes over all points before spatial filter
!      ALLOCATE (ptvar(npts(ifil)*6))
!      ALLOCATE (ptvar3(npts(ifil)*ncomp))   ! MP36 to be defined later to avoid overflow
!initiate to 0.0

    grFX=0.0
    grFY=0.0
    grFZ=0.0
    XX=0.0
    XY=0.0
    XZ=0.0
    YY=0.0
    YZ=0.0
    ZZ=0.0
    ptvar=0.0
    ptvar3=0.0
!=============================================================================
! Storage of the used data in grFX, grFY, grFZ, XX, XY, XZ, YY, YZ, ZZ arrays
!=============================================================================

    itake=0
      do i=1,nptot
         if(datatot(i,1).ge.xmin.and.datatot(i,1).le.xmax) then
            if(datatot(i,2).ge.ymin.and.datatot(i,2).le.ymax) then

              itake=itake+1 

              grFX(itake)= datatot(i,1)
              grFY(itake)= datatot(i,2)
              grFZ(itake)= datatot(i,3)

!=====================================================================
! Adding a test: if RTVAR==0, it means we don't want to invert the component
! Then we put the data to NULL
!=====================================================================

              if (rtvar(nbn+1) == 0) then     
                XX(itake)=-9999
                datatot(i,4)=-9999
              else
                XX(itake)= datatot(i,4)
              endif

              if (rtvar(nbn+2) == 0) then     
                XY(itake)=-9999
                datatot(i,5)=-9999
              else
                XY(itake)= datatot(i,5)
              endif

              if (rtvar(nbn+3) == 0) then     
                XZ(itake)=-9999
                datatot(i,6)=-9999
              else
                XZ(itake)= datatot(i,6)
              endif

              if (rtvar(nbn+4) == 0) then     
                YY(itake)=-9999
                datatot(i,7)=-9999
              else
                YY(itake)= datatot(i,7)
              endif

              if (rtvar(nbn+5) == 0) then     
                YZ(itake)=-9999
                datatot(i,8)=-9999
              else
                YZ(itake)= datatot(i,8)
              endif

              if (rtvar(nbn+6) == 0) then     
                ZZ(itake)=-9999
                datatot(i,9)=-9999
              else
                ZZ(itake)= datatot(i,9)
              endif
!CT 2026-03-26 put all the data outside the selected area to -9999
            else
                datatot(i,4:9)=-9999
            end if
         else
            datatot(i,4:9)=-9999   
         end if
      end do
      
!test CT 2026-03-26        open(unit=222,file='datatot.txt',status="UNKNOWN")
!        write(222,'(9f13.3)') ((datatot(i,j), j=1,9), i=1,nptot)
!        close(222)
      write(*,*)'    There is no need to substracte the mean value to FTG data'
      write(inout,*)'    There is no need to substracte the mean value to FTG data'

!=====================================================================
! Calculation of the covariance of the data
! At that moment, we only take constant covariance over the whole data
! Except for gradient where we can have a RTVAR for each component
!
! 2026-04-02 FIXED the pb of segmentation fault comming from 
!             ptvar3 not returned in case of Foward model (INV=FALSE)
!             solved the pb of direct modelling of selected components
!=====================================================================
!      if(INV) then
         select case (modvar(ifil))
         case (0)
            write(inout,*)''
            write(inout,*)'    One covariance for each components'
!=====================================================================
! before we calculated ptvar3 for all the data with the same RTVAR,
!            ptvar3(:) = 1./(rtvar(ifil)*rtvar(ifil))
!
! Now we calculate the ptvar3 with the associated RTVAR
! When RTVAR corresponds to a data percentage, it doesn't work for small values (~0) 
! We now take the percentage in relation to the MIN and MAX amplitude of the DATA
!
! 17-02-2026 I'm not sure about the rightness of rtvar(nbn+ifil+j-1)... FIXED
!
! 24-03-2026 datatot dimension (nptot,9) is different from that of ptvar3 (npts*ncomp) 
! 26-03-2026 Fixed
!
! 26-03-2026 Modified the perc definition to take only the selected area
!            not the whole area. 
!=====================================================================
            ALLOCATE (perc2(6))
            perc2(:)=0.0d0
            perc2(1)=maxval(XX)-minval(XX)
            perc2(2)=maxval(XY)-minval(XY)
            perc2(3)=maxval(XZ)-minval(XZ)
            perc2(4)=maxval(YY)-minval(YY)
            perc2(5)=maxval(YZ)-minval(YZ)
            perc2(6)=maxval(ZZ)-minval(ZZ)
            
            do j=1,6
              perc2(j)=perc2(j)*rtvar(nbn+j)/100 ! perc2= 0 or %rtvar
!test              write(*,*)' PERC2=', perc2(j)

                do i=1,nptot 
                  if (datatot(i,j+3) .ne. -9999) then
                    if (perc2(j) .ne. 0.d0) then        ! test for the RTVAR non null
                        ptvar(i+(j-1)*nptot)=1./(perc2(j)*perc2(j))
!test                        write(*,*) 'comp,data', j,i, ptvar(i+(j-1)*nptot)
                    else
                        ptvar(i+(j-1)*nptot)=-9999    ! component ignored (rtvar=0)
!test                        write(*,*) 'comp,data', j,i, ptvar(i+(j-1)*nptot)
                    endif 
                  else !for component that is not in the selected area
                    ptvar(i+(j-1)*nptot)=-9999   
!test                    write(*,*) 'comp,data', j,i, ptvar(i+(j-1)*nptot)         
                  endif         
                enddo   
            enddo

!2026-03-26 first loop to calculate the size allocated for ptvar3 - avoids overflow
            iter=0
            do j=1,nptot*6
              if (ptvar(j) .ne. -9999) then
                iter=iter+1
              endif
            enddo
            ALLOCATE (ptvar3(iter))
            
!2026-03-25 must be nptot: ptvar is filled over nptot entries per component
!           do j=1,npts(ifil)*6
            iter=0
            do j=1,nptot*6     
              if (ptvar(j) .ne. -9999) then
                iter=iter+1
                ptvar3(iter)=ptvar(j)
!test                write(*,*)'j=',j,'iter=',iter,'ptvar3',ptvar3(iter)
              endif
            enddo
         
         case default
            write(inout,*)''
            write(*,*)''
            write(*,*)'Constant covariance not yet defined'
            write(*,*)'Maybe it will be interresting to define different values &
                &according to the FTG component'
            STOP
         end select
!      end if
    
!test    open(111,file='grread.out',status='UNKNOWN')
!    write(111,*) ptvar3(:)
!    close(111)
    
    END SUBROUTINE GRREAD
